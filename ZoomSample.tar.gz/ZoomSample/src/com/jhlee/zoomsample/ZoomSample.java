package com.jhlee.zoomsample;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

public class ZoomSample extends Activity {
	private RRZoomView mView;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mView = (RRZoomView)findViewById(R.id.zoomView);
        Bitmap bmp = BitmapFactory.decodeResource(this.getResources(), R.drawable.sample_captured_receipt);
        mView.setBitmap(bmp);
        
        /*
        //setContentView(R.layout.main);
        setContentView(mView);
        mView.setFocusable(true);
        */
        
        /*setContentView(new RRZoomButtonView(this));*/
        
    }
}